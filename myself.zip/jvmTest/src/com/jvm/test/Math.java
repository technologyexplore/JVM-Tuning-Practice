package com.jvm.test;

import com.jvm.test.modal.User;

public class Math {
    public static final int initData = 666;
    public static User user = new User();

    public int compute(){ //一个方法对应一款栈帧内存区域
        int a = 1;
        int b = 2;
        int c = (a + b) * 10 * (a + b);
        return c;
    }
    //为了让cpu彪高，故意这样写
    public static void main(String[] args) {
        Math math = new Math();
        while (true){
            math.compute();
        }
    }
}
