package com.jvm.test;

public class DeadLockTest {
    private static Object lock1 = new Object();
    private static Object lock2 = new Object();
    public static void main(String[] args) {
        new Thread(() -> {
            synchronized (lock1){
                try{
                    System.out.println("thread1 begin");
                    Thread.sleep(5000);
                }catch (InterruptedException e){
                }
                synchronized (lock2){
                    System.out.println("Thread1 end");
                }
            }
        }).start();

        new Thread(() -> {
            synchronized (lock2){
                try{
                    System.out.println("thread2 begin");
                    Thread.sleep(5000);
                }catch (InterruptedException e){
                }
                synchronized (lock1){
                    System.out.println("Thread2 end");
                }
            }
        }).start();
        System.out.println("main Thread End");
    }

    //结果：程序会出现两个死锁，线程1由于在执行第一个线程进行锁的时候，睡眠了5秒，这时候，线程2把lock2锁了，也就是线程1无法获得lock2了，所以永远死锁
}
